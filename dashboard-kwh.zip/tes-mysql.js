// tes-mysql.js
const mysql = require('mysql2');

// Konfigurasi koneksi ke database MySQL
const db = mysql.createPool({
  host: 'localhost',
  user: 'root',
  password: '',
  database: 'dashboard-kwh',
}).promise();

// Fungsi untuk menguji koneksi dan query database
async function testDatabase() {
  try {
    // Mengambil waktu saat ini dari database
    const [now] = await db.query('SELECT NOW() AS now');
    console.log('Current time from database:', now[0].now);

    // Mengambil data terbaru dari tabel data_kwh
    const [rows] = await db.query('SELECT * FROM data_kwh ORDER BY datetime DESC LIMIT 10');
    console.log('Recent sensor data:', rows);
  } catch (err) {
    console.error('Database error:', err);
  }
}

// Menjalankan fungsi untuk menguji database
testDatabase();