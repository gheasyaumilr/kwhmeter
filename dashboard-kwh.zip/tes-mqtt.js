// tes-mqtt.js
const mqtt = require('mqtt');

const mqttOptions = { reconnectPeriod: 1000 };
const mqttClient = mqtt.connect('mqtt://127.0.0.1', mqttOptions);

//Fungsi untuk menghubungkan ke MQTT Broker
mqttClient.on('connect', () => {
  console.log('Connected to MQTT broker');

  mqttClient.subscribe('sensor/data', (err) => {
    if (err) {
      console.error('Subscription error:', err);
    } else {
      console.log('Subscribed to sensor/data');
    }
  });
  
});

//Fungsi Ketika Menerima Pesan
mqttClient.on('message', (topic, message) => {
  if (topic === 'sensor/data') {
    const newSensorData = message.toString();
    console.log('Received:', newSensorData);
  }
});

//Fungsi Untuk Reconnect 
mqttClient.on('reconnect', () => {
  console.log('Reconnecting to MQTT broker...');
});

//Fungsi ketika OFFLINE
mqttClient.on('offline', () => {
  console.log('MQTT client offline');
});

//Fungsi ketika ERROR
mqttClient.on('error', (err) => {
  console.error('MQTT error:', err);
});