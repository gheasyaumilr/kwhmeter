// logger-service.js
// Menerima data dari mqtt simpan ke mysql

const mqtt = require('mqtt');
const mysql = require('mysql2');

//SETTING KONEKSI KE MYSQL---------------------------------------
const db = mysql.createPool({
    host: 'localhost',
    user: 'root',
    password: '',
    database: 'dashboard-kwh'
}).promise();

//SETTING KONEKSI KE MQTT BROKER---------------------------------
const mqttOptions = {
    reconnectPeriod: 1000,
    username: "loggerservice",
    password: "12345678"
};
const mqttClient = mqtt.connect("mqtt://127.0.0.1", mqttOptions);
const topikData = "sensor/data";

//Fungsi simpan data ke MySQL
async function simpanData(voltage, current, power) {
    try{
        const query = "INSERT INTO data_kwh (voltage, current, power) VALUES (?, ?, ?)";
        const values = [voltage, current, power];
        await db.query(query, values);
        console.log('Berhasil simpan data ke database');
    }catch(error){
        console.log('Gagal simpan ke database:', error);
    }
}

//Ketika client berhasil terhubung ke MQTT Broker
mqttClient.on('connect', () => {
    console.log("Berhasil terhubung ke MQTT Broker!");
    mqttClient.subscribe(topikData, (error) => {
        if(error){
            console.log("Error subscribe:", error);
        }else{
            console.log("Berhasil subscribe ke topik", topikData);
        }
    });
});

//Ketika client menerima data dari topik yang di Subscribe
mqttClient.on('message', (topic, message) => {
    console.log("Menerima pesan dari topik", topic);
    console.log("Pesan:", message.toString());
    const data = message.toString();
    const sensorData = JSON.parse(data);
    simpanData(sensorData.voltage, sensorData.current, sensorData.power);
});

//Ketika client berusaha menghubungkan ulang ke MQTT Broker
mqttClient.on('reconnect', () => {
    console.log("sedang berusaha menghubungkan ulang ke broker...");
});

//Ketika client OFFLINE
mqttClient.on('offline', () => {
    console.log("Client oflline!");
});

//Ketika client mengalami error
mqttClient.on('error', (error) => {
    console.log("Client Error:", error);
})