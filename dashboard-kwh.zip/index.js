const express = require('express');
const hbs = require('hbs');
const path = require("path");
const mysql = require('mysql2');
const { json } = require('express');
const app = express();
app.set("view engine", "hbs");
app.set("views", path.join(__dirname, "/views"));

// Konfigurasi koneksi ke database MySQL
const db = mysql.createPool({
  host: 'localhost',
  user: 'root',
  password: '',
  database: 'dashboard-kwh',
}).promise();

//akses ke file statis views/assets
app.use(express.static(path.join(__dirname, "views/assets")));

//Route Utama
app.get("/", function (req, res) {
    res.render("index", {
        nama: "Rahmat",
        title: "Selamat Datang di Kelas Robot 2025"
    });
});

//route Data
app.get("/data", async function (req, res) {
    const sql = "SELECT * FROM data_kwh ORDER BY id DESC";
    try {
        const [rows] = await db.query(sql);
        var formattedData = [];
        rows.forEach(function (row) {
            var id = row.id;
            var voltage = row.voltage;
            var current = row.current;
            var power = row.power;
            var energy = row.energy;
            var datetime = row.datetime;
            const date = new Date(datetime);
            const year = date.getFullYear();
            const month = date.getMonth() + 1;
            const day = date.getDate();
            const hours = date.getHours();
            const minutes = date.getMinutes();
            const seconds = date.getSeconds();
            var formattedRow = {
                id: id,
                voltage: voltage,
                current: current,
                power: power,
                energy: energy,
                datetime: `${year}-${month}-${day} ${hours}:${minutes}:${seconds}`
            };
            formattedData.push(formattedRow);
        });
        console.log(formattedData);
        res.render("data", {
            data: formattedData
        });
    } catch (err) {
        console.error(err);
        res.status(500).send("Database error");
    }
});

//route api data json
app.get("/api/data", async function (req, res) {
    const sql = "SELECT * FROM data_kwh ORDER BY id DESC";
    try {
        const [rows] = await db.query(sql);
        var formattedData = [];
        rows.forEach(function (row) {
            var id = row.id;
            var voltage = row.voltage;
            var current = row.current;
            var power = row.power;
            var energy = row.energy;
            var datetime = row.datetime;
            const date = new Date(datetime);
            const year = date.getFullYear();
            const month = date.getMonth() + 1;
            const day = date.getDate();
            const hours = date.getHours();
            const minutes = date.getMinutes();
            const seconds = date.getSeconds();
            var formattedRow = {
                id: id,
                voltage: voltage,
                current: current,
                power: power,
                energy: energy,
                datetime: `${year}-${month}-${day} ${hours}:${minutes}:${seconds}`
            };
            formattedData.push(formattedRow);
        });
        res.json(formattedData);
    } catch (err) {
        console.error(err);
        res.status(500).send("Database error");
    }
});

//menjalankan server pada port 3000
app.listen(3000, function () {
    console.log("Server is running on port 3000");
});